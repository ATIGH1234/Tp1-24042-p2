# TP1 – Partie B (contract-first)

    cd emprunt-contractfirst
    mvn generate-sources      # génère le code dans target/generated-sources/wsimport
    mvn compile exec:java     # WSDL : http://localhost:8080/bib/EmpruntService?wsdl

Depuis la racine du dossier (là où se trouve `xml/`) :

    curl -i -X POST http://localhost:8080/bib/EmpruntService -H 'Content-Type: text/xml; charset=utf-8' -H 'SOAPAction: "http://supnum.mr/bib/emprunterLivre"' --data-binary @xml/11-cf-emprunter.xml

Autres cas : `12-cf-indisponible.xml` (livre déjà emprunté), `13-cf-isbn-invalide.xml` (ISBN invalide, à tester avec et sans `@SchemaValidation`).
`01-emprunter.xml` (paramètres non qualifiés) sert à la question 2 de l'étape 6.
