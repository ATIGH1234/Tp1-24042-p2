# TP1 – SOAP et WSDL : réponses (Partie B uniquement)

**Étudiant :** 24042  **Groupe :** …

Les fichiers de requêtes sont dans `xml/` (voir `README.md` pour les commandes curl).

---

## Partie B – Contract-first

### Étape 5 – Générer le code depuis le WSDL

1. Dans le WSDL : l'opération est `emprunterLivre` (dans `portType` `EmpruntPortType`) ; son fault est `LivreIndisponible`, de message `LivreIndisponibleFault` (élément `bib:LivreIndisponible`) ; l'action SOAP est `http://supnum.mr/bib/emprunterLivre` (dans `soap:operation soapAction`).
2. `EmpruntType emprunterLivre(String idAdherent, String isbn) throws LivreIndisponibleFault` (avec les annotations `@WebMethod`, `@WebParam`, `@WebResult`, `@RequestWrapper`, `@ResponseWrapper`). `IsbnType`, qui est une restriction de `xs:string`, devient un simple `String`.
3. `dateRetour` (`xs:date`) devient `XMLGregorianCalendar`, alors que dans la partie A c'était un `String` (`xs:string` dans le WSDL généré).
4. La classe d'exception est `LivreIndisponibleFault`. Son nom vient du **nom du `wsdl:message`** (`LivreIndisponibleFault`), et non du nom du fault (`LivreIndisponible`). Ce dernier donne la classe de données `LivreIndisponible` (élément du schéma), portée par l'exception.

### Étape 6 – Implémenter et comparer

1. Non, ce n'est pas exactement mon fichier : le WSDL est celui de `wsdlLocation`, republié par Metro (l'adresse `soap:address` peut être ajustée). Il contient bien le motif de l'ISBN (`xs:pattern`) et le type `xs:date`, les types étant définis dans le contrat fourni, avec un schéma intégré, alors qu'en partie A le schéma est séparé (`?xsd=1`).
2. Oui : les éléments `idAdherent` et `isbn` doivent être **qualifiés** (`<bib:idAdherent>`, `<bib:isbn>`), car le schéma écrit à la main a `elementFormDefault="qualified"` (contrairement au schéma généré en partie A). L'en-tête `SOAPAction` est celui du contrat (`http://supnum.mr/bib/emprunterLivre`), alors que celui de la partie A était vide. Fichiers : `xml/11-cf-emprunter.xml`, `12-cf-indisponible.xml`, `13-cf-isbn-invalide.xml`.
3. Sans `@SchemaValidation`, l'ISBN `978-2-10` n'est **pas refusé** : JAXB ne vérifie pas le motif, et l'implémentation ne le fait pas non plus (la réponse normale est renvoyée). Avec `@SchemaValidation`, le message est validé contre le XSD et refusé par une Fault `Client` (SOAP 1.1, HTTP 500) dont le `faultstring` indique une erreur de validation (`cvc-pattern-valid`: la valeur n'est pas conforme au motif de `IsbnType`).
4. Sans `wsdlLocation`, Metro **régénère** le WSDL à partir des annotations (comme en partie A) : le motif de l'ISBN disparaît (`xs:string`), les noms (binding, port type, messages) et le `soapAction` changent (`""`), et la forme du schéma peut changer. Le contrat n'est plus celui que l'on a écrit : on perd l'avantage du contract-first.
